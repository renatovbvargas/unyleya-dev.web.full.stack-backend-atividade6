package br.edu.unyleya.backend.cidadaos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CidadaosApplicationTests {

	@Test
	void contextLoads() {
	}

}
