package br.edu.unyleya.backend.cidadaos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CidadaosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CidadaosApplication.class, args);
	}

}
